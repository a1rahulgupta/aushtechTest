import { Component, OnInit, Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../../services/config/config.service';
import { ProductService } from '../../../services/product/product.service';
import { routerTransition } from '../../../services/config/config.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {
  productId: any;
  productDetail: any ={};
  public imageUrl = 'http://localhost:3001/uploads/';
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, private productService: ProductService, private toastr: ToastrService) {
    this.route.params.subscribe(params => {
			this.productId = params['id'];
			// check if ID exists in route & call update or add methods accordingly
			if (this.productId && this.productId !== null && this.productId !== undefined) {
				this.getProductDetails(this.productId);
			}
		});
  }

  ngOnInit() {
  }

  getProductDetails(productId){
    this.productService.getProductById({ProductId:productId}).subscribe((result) => {
      const rs = result;
      if (rs.code === 200) {
        this.productDetail = rs.data.productData;
      } else {
        this.toastr.error(rs.message);
      }
    });
  }
}
