import { Component, OnInit, Inject } from '@angular/core';
import { ProductService } from 'src/app/services/product/product.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  public totalCount: number = 0;
  public pagination: any = {
    'page': 1,
    'count': 5,
    'searchText': "",
    'like': false,
    'stock':'in'
  };
  allProductList: any = [];
  public imageUrl = 'http://localhost:3001/uploads/';
  constructor(private productService: ProductService, private toastr: ToastrService) { }

  ngOnInit() {
    this.getAllProduct();
  }

  public getAllProduct() {
    this.productService.getAllProduct(this.pagination).subscribe((result) => {
      if (result.code === 200) {
        this.totalCount = Math.ceil(parseInt(result.data.total_count) / this.pagination.count);
        this.allProductList = result.data.data;
      } else {
        this.toastr.error(result.message);
      }
    });
  }

  next() {
    this.pagination.page = this.pagination.page + 1
    this.getAllProduct();
  }

  prev() {
    this.pagination.page = this.pagination.page - 1;
    this.getAllProduct();
  }

  deleteProduct(productId: number) {
    const r = confirm('Are you sure?');
    if (r === true) {
      this.productService.deleteProduct({ productId: productId }).subscribe((result) => {
        const rs = result;
        if (rs.code === 200) {
          this.toastr.success('Success', rs.message);
          this.getAllProduct();
        } else {
          this.toastr.error(rs.message);
        }

      })
    }
  }
  likeProduct(productId: number,status) {
      let data = 
        { productId: productId ,status:status}
      this.productService.likeProduct(data).subscribe((result) => {
        const rs = result;
        if (rs.code === 200) {
          this.toastr.success('Success', rs.message);
          this.getAllProduct();
        } else {
          this.toastr.error(rs.message);
        }

      })

  }
}