import { Component, OnInit, Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';
import { ValidationService } from '../../../services/config/config.service';
import { ProductService } from '../../../services/product/product.service';
import { routerTransition } from '../../../services/config/config.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.scss']
})
export class ProductAddComponent implements OnInit {
  currentRate = 8;
  productAddForm: FormGroup;
  productId: any;
  prdctData: any = {};
  public checks = [
    {description: "Delhi", value: 'delhi'},
    {description: "Mumbai", value: 'mumbai'},
    {description: "Kolkata", value: 'kolkata'},
    {description: "Channai", value: 'channai'}
  ];
  public imageUrl = 'http://localhost:3001/uploads/';
  myForm: any;
  constructor(private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, private productService: ProductService, private toastr: ToastrService) {
    this.route.params.subscribe(params => {
			this.productId = params['id'];
			// check if ID exists in route & call update or add methods accordingly
			if (this.productId && this.productId !== null && this.productId !== undefined) {
				this.getProductDetails(this.productId);
			} else {
				this.createForm(null);
			}
		});
  }
  ngOnInit() {

  }

  doRegister() {
		if (this.productId && this.productId !== null && this.productId !== undefined) {
      this.productAddForm.value.id = this.productId;
      this.updateProduct();
		} else {
      this.productId = null;
      this.addNewProduct();
    }
}

addNewProduct(){
  this.productAddForm.value.image  = this.prdctData.productImage;
  this.productService.addNewProduct(this.productAddForm.value).subscribe((res: any) => {	
    if (res.code === 200) {
      this.toastr.success(res.message, 'Success');
      this.router.navigate(['/list']);
    } else {
      this.toastr.error(res.message, 'Failed');
    }
})
}
updateProduct(){
  this.productAddForm.value.image  = this.prdctData.productImage;
  this.productService.updateProduct(this.productAddForm.value).subscribe((result) => {
    const rs = result;
    if (rs.code === 200) {
      this.router.navigate(['/list']);
      this.toastr.success("success",rs.message);
    } else {
      this.toastr.error(rs.message);
    }
  });
}
  getProductDetails(ProductId){
    this.productService.getProductById({ProductId:ProductId}).subscribe((result) => {
      const rs = result;
      if (rs.code === 200) {
        this.createForm(rs.data);
      } else {
        this.toastr.error(rs.message);
      }
    });
  }



  createForm(data) {
    if (data === null) {
      this.productAddForm = this.formBuilder.group({
        name: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
        description: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(500)]],
        price: ['', [Validators.required]],
        image:[''],
        rating:[''],
        locations: this.formBuilder.array([]),
        stock: ['']
      });
    } else {
      
      this.prdctData.productImage = data.productData.image
      this.productAddForm = this.formBuilder.group({
        name: [data.productData.name, [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
        description: [data.productData.description, [Validators.required, Validators.minLength(5), Validators.maxLength(500)]],
        price: [data.productData.price, [Validators.required]],
        rating:[data.productData.rating],
        locations: new FormArray([]),
        stock: [data.productData.stock]
      });
      this.loadArray(data.productData.locations)
    }
  }

  loadArray(data){
    const formArray: FormArray = this.productAddForm.get('locations') as FormArray;
    data.forEach(element => {
      console.log(element)
      formArray.push(new FormControl(element));
    });
  }
 
  onCheckChange(event) {
    const formArray: FormArray = this.productAddForm.get('locations') as FormArray;
    if(event.target.checked){
      formArray.push(new FormControl(event.target.value));
    }
    else{
      let i: number = 0;
      formArray.controls.forEach((ctrl: FormControl) => {
        if(ctrl.value == event.target.value) {
          formArray.removeAt(i);
          return;
        }
        i++;
      });
    }
  }
  fileChange(e, type?) {
    let form = new FormData();
    form.append('file', e.target.files[0]);
    this.fileUpload(form, type);
  }
  fileUpload(image, type) {
      this.productService.fileUpload(image).subscribe((result) => {
      if (result.status == 1) {
        this.prdctData.productImage = result.fileName 
      }
    });
  }

}

