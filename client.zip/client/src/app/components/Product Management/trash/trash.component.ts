
import { Component, OnInit, Inject } from '@angular/core';
import { ProductService } from 'src/app/services/product/product.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-trash',
  templateUrl: './trash.component.html',
  styleUrls: ['./trash.component.scss']
})
export class TrashComponent implements OnInit {

  public totalCount: number = 0;
  public pagination: any = {
    'page': 1,
    'count': 5,
    'searchText': ""
  };
  allProductList: any = [];
  public imageUrl = 'http://localhost:3001/uploads/';
  constructor(private productService: ProductService, private toastr: ToastrService) { }

  ngOnInit() {
    this.getAllProductTrash();
  }

  public getAllProductTrash() {
    this.productService.getAllProductTrash(this.pagination).subscribe((result) => {
      if (result.code === 200) {
        this.totalCount = Math.ceil(parseInt(result.data.total_count) / this.pagination.count);
        this.allProductList = result.data.data;
      } else {
        this.toastr.error(result.message);
      }
    });
  }

  next() {
    this.pagination.page = this.pagination.page + 1
    this.getAllProductTrash();
  }

  prev() {
    this.pagination.page = this.pagination.page - 1;
    this.getAllProductTrash();
  }

  restoreProduct(productId: number) {
    const r = confirm('Are you sure?');
    if (r === true) {
      this.productService.restoreProduct({ productId: productId }).subscribe((result) => {
        const rs = result;
        if (rs.code === 200) {
          this.toastr.success('Success', rs.message);
          this.getAllProductTrash();
        } else {
          this.toastr.error(rs.message);
        }

      })
    }
  }
  deleteProductPermanant(productId: number) {
    const r = confirm('Are you sure?');
    if (r === true) {
      this.productService.deleteProductPermanant({ productId: productId }).subscribe((result) => {
        const rs = result;
        if (rs.code === 200) {
          this.toastr.success('Success', rs.message);
          this.getAllProductTrash();
        } else {
          this.toastr.error(rs.message);
        }

      })
    }
  }
}