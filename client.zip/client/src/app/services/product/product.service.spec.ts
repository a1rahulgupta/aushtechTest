
import { TestBed, inject } from '@angular/core/testing';



describe('', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: []
    });
  });
});

