
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' , 'Access-Control-Allow-Origin': '*','Access-Control-Allow-Credentials': 'true' })
};



const apiUrl = 'http://localhost:3001/api/';

@Injectable()
export class ProductService {

  constructor(private http: HttpClient) { }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  }

  getAllProduct(data): Observable<any> {
    const url = apiUrl + 'getAllProduct';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  getAllProductTrash(data): Observable<any> {
    const url = apiUrl + 'getAllProductTrash';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }


  addNewProduct(data): Observable<any> {
    const url = apiUrl + 'addNewProduct';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  getProductById(ProductId): Observable<any> {
    const url = apiUrl + 'getProductById';
    return this.http.post(url,ProductId, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  
  deleteProduct(data): Observable<any> {
    const url = apiUrl + 'deleteProduct';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  likeProduct(data): Observable<any> {
    const url = apiUrl + 'likeProduct';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  restoreProduct(data): Observable<any> {
    const url = apiUrl + 'restoreProduct';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  deleteProductPermanant(data): Observable<any> {
    const url = apiUrl + 'deleteProductPermanant';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  updateProduct(data): Observable<any> {
    const url = apiUrl + 'updateProduct';
    return this.http.post(url, data, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }
  fileUpload(data): Observable<any> {
    const url = apiUrl + 'fileUpload';
    return this.http.post(url, data)
      .pipe(
        catchError(this.handleError)
      );
  }
}