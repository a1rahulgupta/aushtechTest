var express = require('express');
var mongoose = require('mongoose');
productModel = mongoose.model('productModel');
var formidable = require('formidable');
const fs = require('fs');
var path = require('path');
var waterfall = require('async-waterfall');

exports.getAllProduct = function (req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    waterfall([
        function (callback) {

            var condition = {};
            condition.isDelete = false;
            condition.isDeletePermanent = false;
                condition.like = req.body.like;
                condition.stock = req.body.stock;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'name': new RegExp(searchText, 'gi')
                }
                ];
            }
            var aggregate = [
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "_id": "$_id",
                    "name": "$name",
                    "image": "$image",
                    "price": "$price",
                    "locations": "$locations",
                    "rating": "$rating",
                    "stock": "$stock",
                    "description": "$description",
                    "like":"$like"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: { "_id": -1 }
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            productModel.aggregate(aggregate).then(function (productData) {
                var data = {};
                data.data = productData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                productModel.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        console.log(err, data)
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Server Error"
            });
        } else {
            res.json({
                code: 200,
                data: data,
                message: "Data found successfully"
            });
        }
    }
    )
}

exports.getAllProductTrash = function (req, res) {
    var finalResponse = {};
    var orgData = {};
    var count = req.body.count ? req.body.count : 0;
    var skip = req.body.count * (req.body.page - 1);
    waterfall([
        function (callback) {

            var condition = {};
            condition.isDelete = true;
            condition.isDeletePermanent = false;
            var searchText = decodeURIComponent(req.body.searchText).replace(/[[\]{}()*+?,\\^$|#\s]/g, "\\s+");
            if (searchText != undefined && searchText != 'undefined') {
                condition.$or = [{
                    'name': new RegExp(searchText, 'gi')
                }
                ];
            }
            var aggregate = [
                {
                    $match: condition
                },
            ];
            var project = {
                $project: {
                    "_id": "$_id",
                    "name": "$name",
                    "image": "$image",
                    "price": "$price",
                    "locations": "$locations",
                    "rating": "$rating",
                    "stock": "$stock",
                    "description": "$description"
                }
            };

            aggregate.push(project);
            var countQuery = [].concat(aggregate);
            aggregate.push({
                $sort: { "_id": -1 }
            });
            aggregate.push({
                $skip: parseInt(skip)
            });
            aggregate.push({
                $limit: parseInt(count)
            });
            productModel.aggregate(aggregate).then(function (productData) {
                var data = {};
                data.data = productData;
                countQuery.push({
                    $group: {
                        _id: null,
                        count: {
                            $sum: 1
                        }
                    }
                });
                productModel.aggregate(countQuery).then(function (dataCount) {
                    var cnt = (dataCount[0]) ? dataCount[0].count : 0;
                    data.total_count = cnt;
                    callback(null, data);
                });
            }).catch(function (err) {
                callback(err, false);
            });
        },
    ], function (err, data) {
        console.log(err, data)
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Server Error"
            });
        } else {
            res.json({
                code: 200,
                data: data,
                message: "Data found successfully"
            });
        }
    }
    )
}

exports.addNewProduct = function (req, res) {
    var finalResponse = {};
    finalResponse.productData = {};
    var productObj = {
        name: req.body.name,
        image: req.body.image,
        price: req.body.price,
        locations: req.body.locations,
        rating: req.body.rating,
        stock: req.body.stock ? req.body.stock : 'in',
        description: req.body.description


    };
    if (!productObj.name || !productObj.price || !productObj.description) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                productModel.findOne({ name: productObj.name, isDelete: false }, function (err, productExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (productExist) {
                            res.json({
                                code: 400,
                                data: {},
                                message: "This product is already exist. please try again with different product."
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },

            function (finalResponse, callback) {
                var obj = {
                    name: productObj.name,
                    image: productObj.image,
                    price: productObj.price,
                    description: productObj.description,
                    locations: productObj.locations,
                    rating: productObj.rating,
                    stock: productObj.stock,
                };

                var productRecord = new productModel(obj);
                productRecord.save(function (err, productData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.productData = productData;
                        callback(null, finalResponse);
                    }
                });

            }
        ], function (err, data) {
            console.log(err, data)
            if (err) {
                res.json({
                    code: 201,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "Product Added Successfully"
                });
            }
        })
    }
}



exports.getProductById = function (req, res) {
    var finalResponse = {};
    finalResponse.productData = {};
    waterfall([
        function (callback) {
            productModel.findOne({ _id: mongoose.Types.ObjectId(req.body.ProductId) }).exec(function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    finalResponse.productData = productData;
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: data,
                message: "Record Found Successfully"
            });
        }
    });

}

exports.updateProduct = function (req, res) {
    var finalResponse = {};
    var productId = mongoose.Types.ObjectId(req.body.id);
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: productId
            }, {
                $set: {
                    productId: req.body.id,
                    name: req.body.name,
                    image: req.body.image,
                    price: req.body.price,
                    rating: req.body.rating,
                    stock: req.body.stock,
                    description: req.body.description,
                    locations: req.body.locations

                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        }

    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record updated successfully!"
            });
        }
    });
}

exports.deleteProduct = function (req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: req.body.productId
            }, {
                $set: {
                    isDelete: true,
                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record deleted successfully!"
            });
        }
    });
}

exports.deleteProductPermanant = function (req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: req.body.productId
            }, {
                $set: {
                    isDeletePermanent: true,
                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record deleted successfully!"
            });
        }
    });
}

exports.restoreProduct = function (req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: req.body.productId
            }, {
                $set: {
                    isDelete: false,
                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record Restore successfully!"
            });
        }
    });
}

exports.likeProduct = function (req, res) {
    var finalResponse = {};
    waterfall([
        function (callback) {
            productModel.findOneAndUpdate({
                _id: req.body.productId
            }, {
                $set: {
                    like: req.body.status,
                }
            }, function (err, productData) {
                if (err) {
                    callback(err, false);
                } else {
                    callback(null, finalResponse);
                }
            });
        },
    ], function (err, data) {
        if (err) {
            res.json({
                code: 201,
                data: {},
                message: "Internal Error"
            });
        } else {
            res.json({
                code: 200,
                data: {},
                message: "Record Update successfully!"
            });
        }
    });
}

exports.fileUpload = function (req, res) {
    let form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        console.log(err)
        var oldpath = files.file.path;
        var newpath = __dirname + '/uploads/' + files.file.name;
        fs.rename(oldpath, newpath, (err) => {
            console.log(err)
            if (err) return res.send({ message: err, status: 0 });
            else return res.send({ message: 'File uploaded successfully!', status: 1, fileName: files.file.name, filePath: 'http://localhost:3001/uploads/' + files.file.name });
        });
    });
};
