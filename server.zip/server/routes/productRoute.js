
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
productModel = mongoose.model('productModel');
var prodcutCtrl = require("../api/controller");


router.post('/getAllProduct', prodcutCtrl.getAllProduct);
router.post('/addNewProduct', prodcutCtrl.addNewProduct);
router.post('/getProductById', prodcutCtrl.getProductById);
router.post('/updateProduct', prodcutCtrl.updateProduct);
router.post('/deleteProduct', prodcutCtrl.deleteProduct);
router.post('/deleteProductPermanant', prodcutCtrl.deleteProductPermanant);
router.post('/restoreProduct', prodcutCtrl.restoreProduct);
router.post('/likeProduct', prodcutCtrl.likeProduct);
router.post('/getAllProductTrash', prodcutCtrl.getAllProductTrash);
router.post('/fileUpload', prodcutCtrl.fileUpload);





module.exports = router;

