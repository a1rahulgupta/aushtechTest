
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var productSchema = Schema({
    name: { type: String, required: true },
    image: { type: String},
    stock : {type: String},
    rating:{type: String},
    locations: [{}],
    price: { type: String},
    description: {type: String},
    like: {type:Boolean,default:false},
    isDelete:{ type: Boolean, default: false},
    isDeletePermanent:{ type: Boolean, default: false}

}, {
    timestamps: true
});



var productModel = mongoose.model('productModel', productSchema);

module.exports = productModel;